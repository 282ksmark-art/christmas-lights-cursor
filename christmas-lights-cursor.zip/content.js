(() => {
  const defaults = { enabled: true, twinkle: true, size: 40 };
  let settings = { ...defaults }, frame = 0, timer = null;
  const style = document.createElement('style');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const selectors = 'html,body,main,section,article,header,footer,nav,aside,div,span,p,h1,h2,h3,h4,h5,h6,ul,ol,li,img,svg,path,canvas,table,td,th,label,a,button,[role="button"]';
  function draw() {
    if (!settings.enabled) { style.remove(); return; }
    const src = chrome.runtime.getURL('cursors/cursor-' + settings.size + '-' + frame + '.png');
    style.textContent = selectors + '{cursor:url("' + src + '") 2 2,auto !important;} input,textarea,[contenteditable="true"],[contenteditable=""],[contenteditable="true"] * {cursor:text !important;} input[type="checkbox"],input[type="radio"],input[type="button"],input[type="submit"],select {cursor:pointer !important;}';
    if (!style.isConnected) (document.head || document.documentElement).appendChild(style);
  }
  function refresh() {
    clearInterval(timer); timer = null; frame = 0; draw();
    if (settings.enabled && settings.twinkle && !reduced.matches && !document.hidden) {
      timer = setInterval(() => { frame = (frame + 1) % 4; draw(); }, 750);
    }
  }
  function sanitize(data) {
    return { enabled: typeof data.enabled === 'boolean' ? data.enabled : true, twinkle: typeof data.twinkle === 'boolean' ? data.twinkle : true, size: [32,40,48].includes(data.size) ? data.size : 40 };
  }
  chrome.storage.local.get(defaults).then(data => { settings = sanitize(data); refresh(); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const data = { ...settings };
    for (const key of Object.keys(defaults)) if (changes[key]) data[key] = changes[key].newValue;
    settings = sanitize(data); refresh();
  });
  document.addEventListener('visibilitychange', refresh);
  reduced.addEventListener('change', refresh);
  addEventListener('pagehide', () => clearInterval(timer));
  addEventListener('pageshow', refresh);
})();
