const defaults = { enabled: true, twinkle: true, size: 40 };
const enabled = document.getElementById('enabled'), twinkle = document.getElementById('twinkle'), size = document.getElementById('size'), status = document.getElementById('status'), preview = document.getElementById('cursorPreview');
let previewTimer, frame = 0;
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
function renderPreview() {
  clearInterval(previewTimer); frame = 0;
  preview.src = 'cursors/cursor-' + size.value + '-0.png';
  preview.style.opacity = enabled.checked ? '1' : '.3';
  if (enabled.checked && twinkle.checked && !reduced.matches) previewTimer = setInterval(() => { frame = (frame + 1) % 4; preview.src = 'cursors/cursor-' + size.value + '-' + frame + '.png'; }, 750);
}
for (const control of [enabled, twinkle, size]) control.disabled = true;
chrome.storage.local.get(defaults).then(data => {
  enabled.checked = data.enabled; twinkle.checked = data.twinkle; size.value = String([32,40,48].includes(data.size) ? data.size : 40);
  for (const control of [enabled, twinkle, size]) control.disabled = false;
  status.textContent = '크리스마스 분위기, 준비 완료'; renderPreview();
}).catch(() => { status.textContent = '설정을 불러오지 못했습니다. 창을 다시 열어주세요.'; });
for (const control of [enabled, twinkle, size]) control.addEventListener('change', async () => {
  try { await chrome.storage.local.set({ enabled: enabled.checked, twinkle: twinkle.checked, size: Number(size.value) }); status.textContent = '저장되었습니다'; renderPreview(); }
  catch { status.textContent = '저장에 실패했습니다. 다시 시도해주세요.'; }
});
reduced.addEventListener('change', renderPreview);
